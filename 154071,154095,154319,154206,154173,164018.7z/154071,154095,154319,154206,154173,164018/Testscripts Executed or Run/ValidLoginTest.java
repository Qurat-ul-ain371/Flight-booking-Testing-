package st;

import org.junit.Test;

import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.junit.After;




public class ValidLoginTest {	
	  private WebDriver driver;

	  @Before
	  public void setUp() {
	    driver = new ChromeDriver();
	  }
	  @After
	  public void tearDown() {
	    driver.quit();
	  }
	  
	  @Test //(priority=1,groups= {"group1"})
	  
	  public void validLogin() {
	    driver.get("https://www.phptravels.net/");
	    driver.manage().window().setSize(new Dimension(1382, 744));
	    driver.findElement(By.cssSelector(".dropdown-login > #dropdownCurrency")).click();
	    {
	      WebElement element = driver.findElement(By.cssSelector(".dropdown-login > #dropdownCurrency"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element).perform();
	    }
	    {
	      WebElement element = driver.findElement(By.tagName("body"));
	      Actions builder = new Actions(driver);
	      builder.moveToElement(element, 0, 0).perform();
	    }
	    driver.findElement(By.linkText("Login")).click();
	    driver.findElement(By.name("username")).click();
	    driver.findElement(By.name("username")).sendKeys("ayeshahaider18@gmail.com");
	    driver.findElement(By.name("password")).click();
	    driver.findElement(By.name("password")).sendKeys("123456");
	    driver.findElement(By.cssSelector(".btn-lg")).click();
	  }
	}
