import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
public class InvalidLoginTest {
  private WebDriver driver;
  @Before
  public void setUp() {
    driver = new ChromeDriver();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void invalidLogin() {
    driver.get("https://www.phptravels.net/login");
    driver.manage().window().setSize(new Dimension(1366, 728));
    driver.findElement(By.name("username")).click();
    driver.findElement(By.name("username")).sendKeys("l154319@lhr.nu.edu.pk");
    driver.findElement(By.name("password")).click();
    driver.findElement(By.name("password")).sendKeys("123456");
    driver.findElement(By.cssSelector(".custom-control-label")).click();
    driver.findElement(By.cssSelector(".btn-lg")).click();
  }
}
