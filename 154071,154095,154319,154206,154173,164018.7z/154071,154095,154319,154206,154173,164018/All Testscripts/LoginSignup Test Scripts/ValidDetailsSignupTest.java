
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
public class ValidDetailsSignupTest {
  private WebDriver driver;
  @Before
  public void setUp() {
    driver = new ChromeDriver();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void validDetailsSignup() {
    driver.get("https://www.phptravels.net/");
    driver.manage().window().setSize(new Dimension(1366, 728));
    driver.findElement(By.cssSelector(".dropdown-login > #dropdownCurrency")).click();
    {
      WebElement element = driver.findElement(By.cssSelector(".dropdown-login > #dropdownCurrency"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.tagName("body"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element, 0, 0).perform();
    }
    driver.findElement(By.linkText("Sign Up")).click();
    driver.findElement(By.name("firstname")).click();
    driver.findElement(By.name("firstname")).sendKeys("Ayshs");
    driver.findElement(By.name("lastname")).click();
    driver.findElement(By.name("lastname")).sendKeys("Haider");
    driver.findElement(By.name("phone")).click();
    driver.findElement(By.name("phone")).sendKeys("03408461509");
    driver.findElement(By.name("email")).click();
    driver.findElement(By.name("email")).sendKeys("l154319@lhr.nu.edu.pk");
    driver.findElement(By.name("password")).click();
    driver.findElement(By.name("password")).sendKeys("12345678");
    driver.findElement(By.name("confirmpassword")).click();
    driver.findElement(By.name("confirmpassword")).sendKeys("12345678");
    driver.findElement(By.cssSelector(".signupbtn")).click();
    driver.findElement(By.name("password")).sendKeys("12345678");
  }
}
