import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
public class BlankcountryfieldsTest {
  private WebDriver driver;
  @Before
  public void setUp() {
    driver = new ChromeDriver();

  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void blankcountryfields() {
    driver.get("https://www.phptravels.net/");
    driver.manage().window().setSize(new Dimension(739, 728));
    driver.findElement(By.cssSelector(".visa")).click();
    driver.findElement(By.cssSelector(".chosen-with-drop span")).click();
    driver.findElement(By.cssSelector(".active-result:nth-child(2)")).click();
    driver.findElement(By.cssSelector(".chosen-with-drop span")).click();
    driver.findElement(By.cssSelector(".chosen-container-active .active-result:nth-child(2)")).click();
    driver.findElement(By.cssSelector(".align-items-center > .col-md-2 > .btn")).click();
    driver.findElement(By.cssSelector(".-focus-")).click();
    driver.findElement(By.cssSelector(".-focus-")).click();
    driver.findElement(By.cssSelector(".align-items-center > .col-md-2 > .btn")).click();
    driver.findElement(By.id("sub")).click();
    {
      WebElement element = driver.findElement(By.id("sub"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.tagName("body"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element, 0, 0).perform();
    }
    driver.findElement(By.name("first_name")).sendKeys("abc");
    driver.findElement(By.name("last_name")).click();
    driver.findElement(By.name("last_name")).sendKeys("xyz");
    driver.findElement(By.name("email")).click();
    driver.findElement(By.name("email")).sendKeys("abc@gmail.com");
    driver.findElement(By.name("confirmemail")).click();
    driver.findElement(By.name("confirmemail")).sendKeys("abc@gmail.com");
    driver.findElement(By.name("phone")).click();
    driver.findElement(By.name("phone")).sendKeys("1111");
    driver.findElement(By.id("sub")).click();
    driver.findElement(By.cssSelector(".btn-success")).click();
  }
}
