
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
public class CheckemailTest {
  private WebDriver driver;
  @Before
  public void setUp() {
    driver = new ChromeDriver();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void checkemail() {
    driver.get("https://www.phptravels.net/");
    driver.manage().window().setSize(new Dimension(754, 728));
    driver.findElement(By.cssSelector(".visa")).click();
    driver.findElement(By.cssSelector(".chosen-with-drop > .chosen-single > div")).click();
    driver.findElement(By.cssSelector(".active-result:nth-child(6)")).click();
    driver.findElement(By.cssSelector(".chosen-with-drop > .chosen-single > div")).click();
    driver.findElement(By.cssSelector(".result-selected:nth-child(8)")).click();
    driver.findElement(By.name("date")).click();
    driver.findElement(By.cssSelector(".-focus-")).click();
    driver.findElement(By.cssSelector(".align-items-center > .col-md-2 > .btn")).click();
    driver.findElement(By.name("first_name")).click();
    driver.findElement(By.name("first_name")).sendKeys("abc");
    driver.findElement(By.name("last_name")).click();
    driver.findElement(By.name("last_name")).sendKeys("xyz");
    driver.findElement(By.name("email")).click();
    driver.findElement(By.name("email")).sendKeys("abc@gmail.com");
    driver.findElement(By.name("confirmemail")).click();
    driver.findElement(By.name("confirmemail")).sendKeys("abc");
    driver.findElement(By.name("phone")).click();
    driver.findElement(By.name("phone")).sendKeys("1111");
    driver.findElement(By.id("sub")).click();
    driver.findElement(By.id("sub")).click();
    {
      WebElement element = driver.findElement(By.id("sub"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.tagName("body"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element, 0, 0).perform();
    }
    driver.findElement(By.name("confirmemail")).sendKeys("abc@gmail.com");
    driver.findElement(By.name("email")).click();
    driver.findElement(By.name("email")).sendKeys("123@gmail.com");
    driver.findElement(By.id("sub")).click();
    driver.findElement(By.name("first_name")).click();
    driver.findElement(By.name("first_name")).sendKeys("abc");
    driver.findElement(By.name("last_name")).click();
    driver.findElement(By.name("last_name")).sendKeys("xyz");
    driver.findElement(By.name("email")).click();
    driver.findElement(By.name("email")).sendKeys("ab@gmail.com");
    driver.findElement(By.name("confirmemail")).click();
    driver.findElement(By.name("confirmemail")).sendKeys("ab@gmail.com");
    driver.findElement(By.name("phone")).click();
    driver.findElement(By.name("phone")).sendKeys("1111");
    driver.findElement(By.name("date")).click();
    driver.findElement(By.cssSelector(".-focus-")).click();
    driver.findElement(By.id("sub")).click();
  }
}
