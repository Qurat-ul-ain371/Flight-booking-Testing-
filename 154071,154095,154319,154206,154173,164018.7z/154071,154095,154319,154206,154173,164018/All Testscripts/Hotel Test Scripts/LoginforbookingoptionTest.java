
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
public class LoginforbookingoptionTest {
  private WebDriver driver;
  @Before
  public void setUp() {
    driver = new ChromeDriver();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void loginforbookingoption() {
    driver.get("https://www.phptravels.net/");
    driver.manage().window().setSize(new Dimension(1366, 728));
    driver.findElement(By.cssSelector(".o1 > .btn")).click();
    driver.findElement(By.cssSelector("li:nth-child(1) .btn:nth-child(4)")).click();
    {
      WebElement element = driver.findElement(By.cssSelector("li:nth-child(1) .btn:nth-child(4)"));
      Actions builder = new Actions(driver);
      builder.doubleClick(element).perform();
    }
    js.executeScript("window.scrollTo(0,77.77777862548828)");
    driver.findElement(By.cssSelector(".btn-wide")).click();
    {
      WebElement element = driver.findElement(By.tagName("body"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element, 0, 0).perform();
    }
    js.executeScript("window.scrollTo(0,350)");
    driver.findElement(By.cssSelector(".room-item:nth-child(2) .btn")).click();
    driver.findElement(By.id("btn-login")).click();
    driver.findElement(By.id("email")).click();
    driver.findElement(By.id("email")).sendKeys("annabella@yahoo.com");
    driver.findElement(By.id("password")).click();
    driver.findElement(By.id("password")).sendKeys("123456");
  }
}
