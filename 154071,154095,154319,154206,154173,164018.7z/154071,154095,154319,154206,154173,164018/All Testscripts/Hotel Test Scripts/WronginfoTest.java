
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
public class WronginfoTest {
  private WebDriver driver;
  @Before
  public void setUp() {
    driver = new ChromeDriver();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void wronginfo() {
    driver.get("https://www.phptravels.net/");
    driver.manage().window().setSize(new Dimension(1382, 744));
    driver.findElement(By.cssSelector(".o1 > .btn")).click();
    driver.findElement(By.cssSelector("li:nth-child(1) .btn:nth-child(4)")).click();
    driver.findElement(By.cssSelector(".btn-wide")).click();
    js.executeScript("window.scrollTo(0,624.4444580078125)");
    driver.findElement(By.cssSelector(".room-item:nth-child(3) .btn")).click();
    driver.findElement(By.id("title")).click();
    {
      WebElement dropdown = driver.findElement(By.id("title"));
      dropdown.findElement(By.xpath("//option[. = 'Ms.']")).click();
    }
    driver.findElement(By.id("title")).click();
    driver.findElement(By.id("first_name")).click();
    driver.findElement(By.id("first_name")).sendKeys("amna");
    driver.findElement(By.id("last_name")).click();
    driver.findElement(By.id("last_name")).sendKeys("blah");
    driver.findElement(By.cssSelector(".col-md-6 > #email")).click();
    driver.findElement(By.cssSelector(".col-md-6 > #email")).sendKeys("amnablah#gmail.com");
    driver.findElement(By.cssSelector(".chosen-single > span")).click();
    driver.findElement(By.cssSelector(".chosen-search-input")).sendKeys("pa");
    driver.findElement(By.cssSelector(".result-selected")).click();
    driver.findElement(By.id("phone_number")).click();
    driver.findElement(By.id("phone_number")).sendKeys("030078601");
    driver.findElement(By.id("cardHolderName")).click();
    driver.findElement(By.id("cardHolderName")).sendKeys("amnablah");
    driver.findElement(By.id("cardNumber")).click();
    driver.findElement(By.id("cardNumber")).sendKeys("1234567812345678");
    driver.findElement(By.id("month")).click();
    driver.findElement(By.id("month")).click();
    driver.findElement(By.name("year")).click();
    {
      WebElement dropdown = driver.findElement(By.name("year"));
      dropdown.findElement(By.xpath("//option[. = '2021']")).click();
    }
    driver.findElement(By.name("year")).click();
    driver.findElement(By.id("cardCVC")).click();
    driver.findElement(By.id("cardCVC")).sendKeys("123");
    driver.findElement(By.id("completeBooking")).click();
    driver.findElement(By.cssSelector(".col-md-6 > #email")).click();
    driver.findElement(By.cssSelector(".col-md-6 > #email")).sendKeys("amnablah@gmail.com");
    driver.findElement(By.id("completeBooking")).click();
    assertThat(driver.switchTo().alert().getText(), is("Authentication Error: Wrong Credentials!"));
  }
}
