
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
public class InvaildDepartDateTest {
  private WebDriver driver;
  @Before
  public void setUp() {
    driver = new ChromeDriver();

  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void invaildDepartDate() {
    driver.get("https://www.phptravels.net/");
    driver.manage().window().setSize(new Dimension(1304, 728));
    driver.findElement(By.cssSelector(".transfer")).click();
    driver.findElement(By.cssSelector("#carlocations_chosen span")).click();
    {
      WebElement element = driver.findElement(By.cssSelector("#carlocations_chosen .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).clickAndHold().perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector("#carlocations_chosen .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector("#carlocations_chosen .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).release().perform();
    }
    driver.findElement(By.cssSelector(".active-result:nth-child(4)")).click();
    {
      WebElement element = driver.findElement(By.cssSelector("#s2id_carlocations2 > .select2-choice"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.tagName("body"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element, 0, 0).perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector("#s2id_carlocations2 > .select2-choice"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).clickAndHold().perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector(".select2-focused"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).release().perform();
    }
    driver.findElement(By.cssSelector(".with-waypoint-sticky")).click();
    {
      WebElement element = driver.findElement(By.cssSelector("#select2-drop > .select2-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).clickAndHold().perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector("#select2-drop > .select2-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector("#select2-drop > .select2-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).release().perform();
    }
    driver.findElement(By.id("dropdate")).click();
    driver.findElement(By.id("dropdate")).sendKeys("56/78/2019");
    driver.findElement(By.cssSelector(".chosen-with-drop span")).click();
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).clickAndHold().perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).release().perform();
    }
    driver.findElement(By.cssSelector(".result-selected:nth-child(13)")).click();
    driver.findElement(By.cssSelector(".chosen-with-drop > .chosen-single > div")).click();
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).clickAndHold().perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).release().perform();
    }
    driver.findElement(By.cssSelector(".result-selected:nth-child(7)")).click();
    driver.findElement(By.cssSelector(".col-md-2:nth-child(5) > .btn-primary")).click();
    driver.close();
  }
}
