
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
public class AllValidTest {
  private WebDriver driver;
  @Before
  public void setUp() {
    driver = new ChromeDriver();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void allValid() {
    driver.get("https://www.phptravels.net/");
    driver.manage().window().setSize(new Dimension(1304, 728));
    driver.findElement(By.cssSelector(".transfer")).click();
    driver.findElement(By.cssSelector("#carlocations_chosen > .chosen-single > div")).click();
    {
      WebElement element = driver.findElement(By.cssSelector("#carlocations_chosen .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).clickAndHold().perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector("#carlocations_chosen .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector("#carlocations_chosen .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).release().perform();
    }
    driver.findElement(By.cssSelector(".active-result:nth-child(4)")).click();
    driver.findElement(By.id("carlocations2")).click();
    {
      WebElement dropdown = driver.findElement(By.id("carlocations2"));
      dropdown.findElement(By.xpath("//option[. = 'Tamarama']")).click();
    }
    driver.findElement(By.id("carlocations2")).click();
    driver.findElement(By.cssSelector(".col-md-3:nth-child(3) .col-6:nth-child(2) .icon-font")).click();
    driver.findElement(By.cssSelector(".chosen-with-drop span")).click();
    driver.findElement(By.cssSelector(".result-selected:nth-child(3)")).click();
    driver.findElement(By.id("returndate")).click();
    driver.findElement(By.id("returndate")).sendKeys("09/11/2019");
    driver.findElement(By.cssSelector(".chosen-with-drop span")).click();
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).clickAndHold().perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    {
      WebElement element = driver.findElement(By.cssSelector(".chosen-with-drop .chosen-results"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).release().perform();
    }
    driver.findElement(By.cssSelector(".result-selected:nth-child(10)")).click();
    driver.findElement(By.cssSelector(".col-md-2:nth-child(5) > .btn-primary")).click();
    {
      WebElement element = driver.findElement(By.cssSelector(".col-md-2:nth-child(5) > .btn-primary"));
      Actions builder = new Actions(driver);
      builder.moveToElement(element).perform();
    }
    driver.close();
  }
}
